#pragma once
#include <string>
using namespace std;
//C. Define and enum type Degree for the programs

enum Degree { SECURITY, NETWORK, SOFTWARE };
static const string degreeTypeStrings[] = { "SECURITY","NETWORK","SOFTWARE" };